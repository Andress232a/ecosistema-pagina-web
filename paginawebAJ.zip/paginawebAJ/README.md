# Página Web de Biodiversidad

## Instrucciones para las imágenes

Para que la página web funcione correctamente, necesitas descargar las siguientes imágenes y colocarlas en la carpeta `images`:

1. `oso-polar.jpg` - Imagen de un oso polar
2. `gorila.jpg` - Imagen de un gorila de montaña
3. `tigre.jpg` - Imagen de un tigre de bengala
4. `panda.jpg` - Imagen de un panda gigante
5. `elefante.jpg` - Imagen de un elefante africano
6. `rinoceronte.jpg` - Imagen de un rinoceronte negro

Puedes obtener estas imágenes de:
- Bancos de imágenes gratuitos como Unsplash o Pexels
- O usar tus propias fotografías

Asegúrate de que las imágenes:
- Tengan un tamaño mínimo de 800x600 píxeles
- Estén en formato JPG
- Sean de buena calidad
- Tengan nombres exactamente como se especifica arriba

## Estructura del proyecto

```
paginawebAJ/
├── images/
│   ├── oso-polar.jpg
│   ├── gorila.jpg
│   ├── tigre.jpg
│   ├── panda.jpg
│   ├── elefante.jpg
│   └── rinoceronte.jpg
├── index.html
├── styles.css
└── README.md
``` 